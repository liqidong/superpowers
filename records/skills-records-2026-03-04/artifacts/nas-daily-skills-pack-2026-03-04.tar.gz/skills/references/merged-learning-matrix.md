# Merged Learning Matrix

更新时间：2026-03-04

## 目标
把“现有技能体系”与“本仓库新增生产技能”打通，形成可执行链路。

## 新增技能
- `main-sub-log-trilium`
- `evidence-debug-loop`
- `agentic-change-contract`
- `prompt-to-prototype-loop`
- `skill-first-packaging`
- `nas-daily-production-system`

## 合并映射

| 场景 | 先用现有技能 | 再用新增技能 | 输出 |
|---|---|---|---|
| 新任务起步 | `brainstorming` / `writing-plans` | `prompt-to-prototype-loop` | 可运行原型 |
| 配置或部署变更 | `verification-before-completion`(收尾) | `agentic-change-contract` | 可审计变更记录 |
| 故障排查 | `systematic-debugging` | `evidence-debug-loop` | 根因与修复证据 |
| 每日收尾 | `lqd`（规则复用） | `main-sub-log-trilium` | 主日志+子笔记 |
| 流程固化 | `writing-skills` | `skill-first-packaging` | 新 SKILL + 脚本 |

## 建议执行顺序（默认）
1. `nas-daily-production-system`
2. `prompt-to-prototype-loop`
3. `agentic-change-contract`
4. `evidence-debug-loop`
5. `main-sub-log-trilium`
6. `skill-first-packaging`

## 合并原则
- 旧技能负责“方法纪律”，新技能负责“你当前任务语境”。
- 新旧技能冲突时，优先安全与可回滚。
- 每次任务结束后，判断是否反向更新 `lqd` 规则。
