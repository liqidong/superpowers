#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
LOCAL_SKILLS_DIR="$ROOT_DIR/skills"

TARGETS=(
  "/home/lqd/.codex/skills"
  "/home/lqd/.agents/skills"
)

SKILLS=(
  "main-sub-log-trilium"
  "evidence-debug-loop"
  "agentic-change-contract"
  "prompt-to-prototype-loop"
  "skill-first-packaging"
  "nas-daily-production-system"
)

for target in "${TARGETS[@]}"; do
  mkdir -p "$target"
  echo "== target: $target"
  for skill in "${SKILLS[@]}"; do
    src="$LOCAL_SKILLS_DIR/$skill"
    dst="$target/$skill"

    if [ ! -d "$src" ]; then
      echo "skip (missing source): $src"
      continue
    fi

    if [ -L "$dst" ]; then
      current="$(readlink -f "$dst")"
      desired="$(readlink -f "$src")"
      if [ "$current" = "$desired" ]; then
        echo "ok (already linked): $skill"
      else
        echo "skip (linked to other path): $dst -> $current"
      fi
      continue
    fi

    if [ -e "$dst" ]; then
      echo "skip (exists, not symlink): $dst"
      continue
    fi

    ln -s "$src" "$dst"
    echo "linked: $skill"
  done
  echo
 done
