# NAS Daily Skills Pack

本目录是可复用的日常生产技能包。

## Skills
- `main-sub-log-trilium`
- `evidence-debug-loop`
- `agentic-change-contract`
- `prompt-to-prototype-loop`
- `skill-first-packaging`
- `nas-daily-production-system`

## 合并学习
见：`references/merged-learning-matrix.md`

## 打包
运行：
```bash
bash skills/scripts/package-skills.sh
```

产物输出：
- `artifacts/nas-daily-skills-pack-YYYY-MM-DD.tar.gz`
- `artifacts/nas-daily-skills-pack-YYYY-MM-DD.tar.gz.sha256`
