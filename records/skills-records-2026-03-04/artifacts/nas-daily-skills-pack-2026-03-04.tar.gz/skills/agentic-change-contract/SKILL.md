---
name: agentic-change-contract
description: Use before deployment or infrastructure changes that require explicit boundaries, rollback, and human approval checkpoints.
---

# Agentic Change Contract

## Overview
高风险变更必须先写“执行合约”，再执行动作。合约定义边界、退出条件和回滚。

## When to Use
- ECS/NAS/网络/端口/代理配置变更
- 自动化任务涉及系统权限
- 需要可审计的变更记录

## Contract Template
- Goal: 目标结果
- Inputs: 环境、文件、依赖
- Steps: 顺序动作
- Exit Criteria: 成功判据
- Rollback: 失败回滚命令
- Approval Points: 必须人工确认的节点

## Workflow
1. 填写合约模板。
2. 标记高风险步骤（网络暴露、权限提升、数据写入）。
3. 执行每一步后立即验证。
4. 失败时按回滚路径恢复。
5. 输出变更摘要和证据。

## Quality Gate
- 是否有明确退出条件。
- 是否存在可执行回滚路径。
- 是否定义了人工审批点。

## Common Mistakes
- 无回滚就直接改线上。
- 把“成功”定义为“看起来好了”。
- 把高风险动作塞进一条不可拆分命令。
