---
name: main-sub-log-trilium
description: Use when writing a daily work journal to Trilium and you need a concise main log plus detailed child notes.
---

# Main/Sub Log for Trilium

## Overview
把每天记录分成两层：
- 主日志：结论与决策
- 子笔记：过程与证据

目标是“1 分钟读懂今天，10 分钟复现过程”。

## When to Use
- 每日收工总结
- 多任务并行的一天
- 需要后续追溯命令、配置、报错和修复

## Workflow
1. 创建当天主日志（`YYYY-MM-DD`）。
2. 主日志只写四块：`关键结果`、`关键决策`、`风险阻塞`、`明日动作`。
3. 每个任务创建 1 条子笔记，记录目标、步骤、命令、异常、修复、验证。
4. 在主日志中添加子笔记索引链接。
5. 子笔记完成后回填主日志一句最终结论。

## Quality Gate
- 主日志是否 1 分钟内可读完。
- 子笔记是否可被未来自己复现。
- 每条关键结论是否附带至少一条证据（命令/日志/配置/截图）。

## Common Mistakes
- 主日志写成流水账。
- 子笔记只有结果没有过程。
- 没有把子笔记链接回主日志。
