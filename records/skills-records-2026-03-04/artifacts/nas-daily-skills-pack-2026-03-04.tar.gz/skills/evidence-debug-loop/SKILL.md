---
name: evidence-debug-loop
description: Use when troubleshooting bugs or infra failures where you need reproducible evidence before applying fixes.
---

# Evidence-Driven Debug Loop

## Overview
排障先抓证据再改动。每次只改一个变量，避免“误修复”。

## When to Use
- 服务不通、超时、重启循环
- 配置修改后行为异常
- 问题偶发且难以稳定复现

## Workflow
1. 固定现象：写出可复现命令和观察指标。
2. 生成 3 个可检验假设。
3. 一次只改 1 个变量并执行验证。
4. 记录 `改动 -> 结果 -> 结论`。
5. 根因确认后，沉淀成检查清单或脚本。

## Command Template
- 现象确认：`<check command>`
- 假设验证：`<single change> && <same check command>`
- 证据记录：`date +%F-%T` + 输出摘要

## Quality Gate
- 是否有复现命令。
- 是否避免一次改多处。
- 是否保留前后对比证据。

## Common Mistakes
- 凭直觉连改多项。
- 修好了但没有证据链。
- 跳过复现直接“猜测修复”。
