---
name: nas-daily-production-system
description: Use when executing daily infrastructure and journaling tasks and you need one integrated workflow across existing and custom skills.
---

# NAS Daily Production System

## Overview
这是融合技能：把你现有技能与本仓库新增技能串成一条稳定日常链路。

## Workflow
1. 启动前：使用 `lqd` 读取规则与既有最佳实践。
2. 新任务探索：用 `prompt-to-prototype-loop` 先打最小闭环。
3. 变更执行：用 `agentic-change-contract` 约束风险边界。
4. 出现异常：切到 `evidence-debug-loop` + `systematic-debugging`。
5. 收尾验证：用 `verification-before-completion` 做结果确认。
6. 日志沉淀：用 `main-sub-log-trilium` 写主/子笔记。
7. 重复任务：用 `skill-first-packaging` 反向沉淀新技能。

## Integration Rules
- 先证据，后结论。
- 先可运行，后优雅。
- 先回滚路径，后高风险执行。
- 主日志只写结论，细节进子笔记。

## Output Standard
每次任务至少产出：
- 一条主日志
- 一条子笔记
- 一条可复用流程（脚本或技能更新）
