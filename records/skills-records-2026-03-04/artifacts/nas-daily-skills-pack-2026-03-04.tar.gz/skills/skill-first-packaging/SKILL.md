---
name: skill-first-packaging
description: Use when a repeated workflow has stabilized and should be converted into a reusable SKILL plus scripts.
---

# Skill-First Packaging

## Overview
重复任务稳定后，立刻技能化：`SKILL.md + 脚本 + 验证命令`。

## When to Use
- 同类任务出现 2 次及以上
- 操作步骤已经清晰
- 希望交给未来自己或他人稳定复用

## Workflow
1. 提取任务触发条件。
2. 提取最小步骤（3-7 步）。
3. 把复杂逻辑下沉到脚本。
4. 在技能中写明验证方式与失败 fallback。
5. 打包并记录版本。

## Packaging Checklist
- `SKILL.md` frontmatter 含 `name` 与 `description`
- 步骤可执行，避免空泛描述
- 验证命令可直接运行
- 包含失败处理路径

## Common Mistakes
- 技能文档写成长篇理论。
- 缺少验证命令，导致不可验收。
- 只写 happy path，没有失败 fallback。
