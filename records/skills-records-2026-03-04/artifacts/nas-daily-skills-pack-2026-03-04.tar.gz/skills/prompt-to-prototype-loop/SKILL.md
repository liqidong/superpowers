---
name: prompt-to-prototype-loop
description: Use when starting a new feature or automation from scratch and you need to reach a working prototype quickly.
---

# Prompt-to-Prototype Loop

## Overview
先做可运行原型，再做结构优化。追求最短反馈回路，不追求首版完美。

## When to Use
- 从 0 到 1 的新需求
- 需求仍在探索中
- 需要快速验证可行性

## Workflow
1. 用自然语言写“目标行为 + 边界 + 最低可接受结果”。
2. 让 agent 生成最小实现。
3. 立刻运行并收集错误。
4. 把错误转换为下一轮约束，继续迭代。
5. 达到最低可接受结果后，冻结原型并进入重构阶段。

## Quality Gate
- 是否真的可运行。
- 是否有明确“最低可接受结果”。
- 是否在每轮迭代中收敛而不是发散。

## Common Mistakes
- 一开始追求通用架构。
- 没有执行验证，只看代码“感觉对”。
- 原型完成后直接上线，不做回归检查。
